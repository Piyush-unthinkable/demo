package com.example.demo;

import javax.swing.*;

public class OrderBlock {

    OrderBlock(){
        JFrame jFrame = new JFrame();
    }

    public static void main(String[] args) {
        new OrderBlock();
    }
}
